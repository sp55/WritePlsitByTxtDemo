//
//  ViewController.m
//  testPlist
//
//  Created by admin on 16/5/6.
//  Copyright © 2016年 AlezJi. All rights reserved.
//

#import "ViewController.h"
#import "EHAddressPickerView.h"
@interface ViewController ()
@property(strong,nonatomic)NSMutableArray *allProviceArr; //所有的省
@property(strong,nonatomic)NSMutableArray *selectAllCityArr; //选中省的市
@property(strong,nonatomic)NSMutableArray *selectAllTownArr; //选中省的选中市的选中区
@property(nonatomic,strong)NSMutableArray *selectedArray; //默认的选中的数组






@property(nonatomic,strong)NSMutableDictionary *writeDic; //重新写一个字典


@property(strong,nonatomic)NSMutableArray *CityNameArr; //cityName


@property(strong,nonatomic)NSMutableArray *tmpSArr; //临时的省的数组
@property(strong,nonatomic)NSMutableArray *tmpCArr; //临时的市的数组


@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    self.allProviceArr=[NSMutableArray array];
    self.selectAllCityArr=[NSMutableArray array];
    self.selectAllTownArr=[NSMutableArray array];
    self.selectedArray=[NSMutableArray array];
    
    
    self.CityNameArr=[NSMutableArray array];
    
    self.tmpSArr=[NSMutableArray array];
    self.tmpCArr=[NSMutableArray array];

    self.writeDic=[NSMutableDictionary dictionary];
}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    
    
    
    NSString *path = [[NSBundle mainBundle] pathForResource:@"test" ofType:@"plist"];
    //所有的省的数组
    NSArray *allArr = [[NSArray alloc] initWithContentsOfFile:path];
    for (NSInteger i=0; i<allArr.count; i++) {
//        [self.tmpSArr removeAllObjects];//先清除所有的临时省

        
        
        NSDictionary *allDic =allArr[i];
//        NSLog(@"==%@",allDic[@"PName"]);

        //所有的省  四川省 。。江苏省。。
        [self.allProviceArr addObject:allDic[@"PName"]];
        
        

//        if(i==0){ //只考虑四川省的市
        
//            [self.tmpCArr removeAllObjects];//先清除所有的临时市

            
            
            //四川省的所有市  成都。。攀枝花 。。。
            NSArray *allCityArr=allDic[@"ListCity"];
            //        NSDictionary *scDict = allArr[0];
//            NSLog(@"===%ld",allCityArr.count);
            
            
            
            for(NSInteger j=0;j<allCityArr.count;j++){  //遍历四川省所有的市
//                [self.tmpSArr removeAllObjects]; //先清除所有的市

                
                NSMutableArray *muTmpArr =[NSMutableArray array];
                NSDictionary *allCityDic=allCityArr[j]; //20个市
                NSLog(@"===%@",allCityDic[@"CName"]);
                
                //四川省的名字
                [self.CityNameArr addObject:allCityDic[@"CName"]];
                
//                NSLog(@"---%ld",self.selectAllCityArr.count);
                [self.selectAllCityArr addObject:allCityDic[@"CName"]]; //市名字 、、、
                
                
                
        

                    //成都市的所有区  锦江区。。青羊区。。金牛区。。
                    NSArray *allTownArr=allCityDic[@"List_Area"]; //区名字   数组里面套字典
//                    NSLog(@"=allTownArr.count==%ld",allTownArr.count); //20个
                    for (NSInteger k=0; k<allTownArr.count; k++) {
                        NSDictionary *allTownDic=allTownArr[k];
//                        NSLog(@"===%@",allTownDic[@"AName"]); //20个名字
                        [muTmpArr addObject:allTownDic[@"AName"]];
                    }
                
//                NSMutableDictionary *muTmpDic=[NSMutableDictionary dictionary];
//                [muTmpDic setObject:muTmpArr forKey:@"Item"];
                
            
                  [self.selectAllTownArr addObject:muTmpArr];

//                }

//            }
 

        }
    }
    
    

//    NSMutableDictionary *muTmpDic=[NSMutableDictionary dictionary];
//    [muTmpDic setObject:self.selectAllTownArr forKey:@"四川省"];
    
    
    
    //最外层
    [self.writeDic setObject:self.selectAllTownArr forKey:@"天津市"];
    
//    [self.writeDic writeToFile:@"/Users/admin/Desktop/PlistArr/230.plist" atomically:YES];
/*
    { 大字典
        [ 北京  天津  河北 四川 。。。所有的省市
            { 四川的市的数组放到以value的形式存到这个字典中
                [ 成都市 攀枝花 。。。所有的市
                    [ 成都市的所有区  锦江区。。青羊区。。金牛区。。
                    ]
                    [
                      攀枝花市的所有区
                    ]
                    []
                    []
                    []

                ]
            }
        ]
        [{[]}]
        [{[]}]
    }
*/
    
    
//    EHAddressPickerView *addressPickView = [EHAddressPickerView shareInstance];
//    [self.view addSubview:addressPickView];
//    addressPickView.block = ^(NSString *provinceString,NSString *cityString,NSString *townString){
//                NSLog(@"===%@%@%@",provinceString,cityString,townString);
//    };
    

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
