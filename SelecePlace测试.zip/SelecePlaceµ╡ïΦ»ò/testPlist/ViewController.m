//
//  ViewController.m
//  testPlist
//
//  Created by admin on 16/5/6.
//  Copyright © 2016年 AlezJi. All rights reserved.
//

#import "ViewController.h"
#import "EHAddressPickerView.h"
@interface ViewController ()



@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
//    NSString *path200 = [[NSBundle mainBundle] pathForResource:@"200" ofType:@"plist"];
//    NSDictionary *dic200=[[NSDictionary alloc] initWithContentsOfFile:path200];
//    
//    NSString *path201 = [[NSBundle mainBundle] pathForResource:@"201" ofType:@"plist"];
//    NSDictionary *dic201=[[NSDictionary alloc] initWithContentsOfFile:path201];
//    
//    NSString *path202 = [[NSBundle mainBundle] pathForResource:@"202" ofType:@"plist"];
//    NSDictionary *dic202=[[NSDictionary alloc] initWithContentsOfFile:path202];
//    
//    
//    NSString *path203 = [[NSBundle mainBundle] pathForResource:@"203" ofType:@"plist"];
//    NSDictionary *dic203=[[NSDictionary alloc] initWithContentsOfFile:path203];
//    
//    NSString *path204 = [[NSBundle mainBundle] pathForResource:@"204" ofType:@"plist"];
//    NSDictionary *dic204=[[NSDictionary alloc] initWithContentsOfFile:path204];
//    
//    NSString *path205 = [[NSBundle mainBundle] pathForResource:@"205" ofType:@"plist"];
//    NSDictionary *dic205=[[NSDictionary alloc] initWithContentsOfFile:path205];
//    
//    NSString *path206 = [[NSBundle mainBundle] pathForResource:@"206" ofType:@"plist"];
//    NSDictionary *dic206=[[NSDictionary alloc] initWithContentsOfFile:path206];
//    
//    NSString *path207 = [[NSBundle mainBundle] pathForResource:@"207" ofType:@"plist"];
//    NSDictionary *dic207=[[NSDictionary alloc] initWithContentsOfFile:path207];
//    
//    NSString *path208 = [[NSBundle mainBundle] pathForResource:@"208" ofType:@"plist"];
//    NSDictionary *dic208=[[NSDictionary alloc] initWithContentsOfFile:path208];
//    
//    NSString *path209 = [[NSBundle mainBundle] pathForResource:@"209" ofType:@"plist"];
//    NSDictionary *dic209=[[NSDictionary alloc] initWithContentsOfFile:path209];
//    
//    NSString *path210 = [[NSBundle mainBundle] pathForResource:@"210" ofType:@"plist"];
//    NSDictionary *dic210=[[NSDictionary alloc] initWithContentsOfFile:path210];
//    
//    NSString *path211 = [[NSBundle mainBundle] pathForResource:@"211" ofType:@"plist"];
//    NSDictionary *dic211=[[NSDictionary alloc] initWithContentsOfFile:path211];
//    
//    NSString *path212 = [[NSBundle mainBundle] pathForResource:@"212" ofType:@"plist"];
//    NSDictionary *dic212=[[NSDictionary alloc] initWithContentsOfFile:path212];
//    
//    
//    NSString *path213 = [[NSBundle mainBundle] pathForResource:@"213" ofType:@"plist"];
//    NSDictionary *dic213=[[NSDictionary alloc] initWithContentsOfFile:path213];
//    
//    NSString *path214 = [[NSBundle mainBundle] pathForResource:@"214" ofType:@"plist"];
//    NSDictionary *dic214=[[NSDictionary alloc] initWithContentsOfFile:path214];
//    
//    NSString *path215 = [[NSBundle mainBundle] pathForResource:@"215" ofType:@"plist"];
//    NSDictionary *dic215=[[NSDictionary alloc] initWithContentsOfFile:path215];
//    
//    NSString *path216 = [[NSBundle mainBundle] pathForResource:@"216" ofType:@"plist"];
//    NSDictionary *dic216=[[NSDictionary alloc] initWithContentsOfFile:path216];
//    
//    NSString *path217 = [[NSBundle mainBundle] pathForResource:@"217" ofType:@"plist"];
//    NSDictionary *dic217=[[NSDictionary alloc] initWithContentsOfFile:path217];
//    
//    NSString *path218 = [[NSBundle mainBundle] pathForResource:@"218" ofType:@"plist"];
//    NSDictionary *dic218=[[NSDictionary alloc] initWithContentsOfFile:path218];
//    
//    NSString *path219 = [[NSBundle mainBundle] pathForResource:@"219" ofType:@"plist"];
//    NSDictionary *dic219=[[NSDictionary alloc] initWithContentsOfFile:path219];
//    
//    
//    
//    
//    NSString *path220 = [[NSBundle mainBundle] pathForResource:@"220" ofType:@"plist"];
//    NSDictionary *dic220=[[NSDictionary alloc] initWithContentsOfFile:path220];
//    
//    NSString *path221 = [[NSBundle mainBundle] pathForResource:@"221" ofType:@"plist"];
//    NSDictionary *dic221=[[NSDictionary alloc] initWithContentsOfFile:path221];
//    
//    NSString *path222 = [[NSBundle mainBundle] pathForResource:@"222" ofType:@"plist"];
//    NSDictionary *dic222=[[NSDictionary alloc] initWithContentsOfFile:path222];
//    
//    
//    NSString *path223 = [[NSBundle mainBundle] pathForResource:@"223" ofType:@"plist"];
//    NSDictionary *dic223=[[NSDictionary alloc] initWithContentsOfFile:path223];
//    
//    NSString *path224 = [[NSBundle mainBundle] pathForResource:@"224" ofType:@"plist"];
//    NSDictionary *dic224=[[NSDictionary alloc] initWithContentsOfFile:path224];
//    
//    NSString *path225 = [[NSBundle mainBundle] pathForResource:@"225" ofType:@"plist"];
//    NSDictionary *dic225=[[NSDictionary alloc] initWithContentsOfFile:path225];
//    
//    NSString *path226 = [[NSBundle mainBundle] pathForResource:@"226" ofType:@"plist"];
//    NSDictionary *dic226=[[NSDictionary alloc] initWithContentsOfFile:path226];
//    
//    NSString *path227 = [[NSBundle mainBundle] pathForResource:@"227" ofType:@"plist"];
//    NSDictionary *dic227=[[NSDictionary alloc] initWithContentsOfFile:path227];
//    
//    NSString *path228 = [[NSBundle mainBundle] pathForResource:@"228" ofType:@"plist"];
//    NSDictionary *dic228=[[NSDictionary alloc] initWithContentsOfFile:path228];
//    
//    NSString *path229 = [[NSBundle mainBundle] pathForResource:@"229" ofType:@"plist"];
//    NSDictionary *dic229=[[NSDictionary alloc] initWithContentsOfFile:path229];
//    
//    NSString *path230 = [[NSBundle mainBundle] pathForResource:@"230" ofType:@"plist"];
//    NSDictionary *dic230=[[NSDictionary alloc] initWithContentsOfFile:path230];
//    
//    
//    
//    
//    
//    NSArray *arr=@[dic200,dic201,dic202,dic203,dic204,dic205,dic206,dic207,dic208,dic209,dic210,dic211,dic212,dic213,dic214,dic215,dic216,dic217,dic218,dic219,dic220,dic221,dic222,dic223,dic224,dic225,dic226,dic227,dic228,dic229,dic230];
//    
//    
//    [arr writeToFile:@"/Users/admin/Desktop/last.plist" atomically:YES];
    

    
    EHAddressPickerView *addressPickView = [EHAddressPickerView shareInstance];
    [self.view addSubview:addressPickView];
    addressPickView.block = ^(NSString *provinceString,NSString *cityString,NSString *townString){
                NSLog(@"===%@%@%@",provinceString,cityString,townString);
    };
    

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
